# RegionalSim 0.3.0-dev — synthetic Columbus metropolitan prototype

An open-source, event-driven, six-domain regional socioeconomic simulation. **Research prototype with partial proxy calibration; not independently validated or operationally certified.** It does not infer death, illness severity, or any policy's desired outcome.

## Install and execute

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install -e .
python -m unittest discover -s tests -v
regional-sim --config configs/development.json --out output/routine
regional-sim --config configs/development.json --days 5 --shock-json configs/power_shock.json --out output/power
regional-sim --households 1024 --days 3 --seed 11 --scenario moderate --out output/quick
```

Windows PowerShell activation: `.venv\Scripts\Activate.ps1`. The runtime depends only on Python >=3.10 and NumPy >=1.24. The simulation has no network access, no runtime downloads, and no optional machine-learning dependency.

The development preset includes **10,000 individual household decision units**, 12 aggregated geographic zones and 24 retailers over 30 days. The large preset (`configs/large.json`) specifies 1,000,000 households, 120 zones and 2,400 retailers. It **initializes** at 1,000,000 households but a complete one-day run did not finish within our 200-second test bound; it is not a performance guarantee. A 100,000-household one-day run completed.

`--config` loads JSON defaults; explicit CLI flags override them. Options: `--households`, `--days`, `--seed`, `--zones`, `--retailers`, `--scenario routine|seasonal|moderate|severe`, `--shock-json`, `--full-trace`, `--sample-rate`, `--free-flow-minutes`, `--disable-coupling`, `--out`. The fixed target is Columbus, OH CBSA 18140; zoning is synthetic and can be refined at higher population scale. Synthetic clock starts on **Monday, April 1, 2024** at 00:00 Eastern local time; there is no daylight-saving transition engine, bank-holiday calendar or other historical event playback.

Example generic external disturbance file:

```json
[{"at_hour":25,"domain":"power","zone":-1,"multiplier":0.35,"duration_hours":24}]
```

Domains: `power`, `road`, `communication`, `supply`, `payments`, `retail`, `services`, `demand`. A zone of -1 selects the full region. Existing factors multiply for overlapping events and each is removed by a distinct restoration event. No response sequence is hand-coded. Routine and seasonal scenarios use no artificial severe shocks. The stochastic moderate/severe distributions are marked **C-level assumptions, not fitted historical hazard distributions**.

## Outputs

Each run writes `daily.csv` (cumulative and daily-state metrics), `summary.json` (configuration, result, event counts, a network-clustering sample), and `traces.ndjson`. The NDJSON contains observations, requested/accepted/executed/completed actions, purchases, goods and payment transfers, deliveries, messages, individual behavioral adoption, protection/other institutional events, shocks and daily state snapshots. Personal records are **sampled deterministically by agent ID** unless `--full-trace` is supplied; all aggregate and institutional records are kept. `--sample-rate 0` suppresses personal traces, not their aggregate event counts. Never treat a sampled NDJSON as a full individual event census.

## Replacing participants' policies

```python
from regional_sim import World, Config
from regional_sim.policy import Action

class ExamplePolicy:
    def decide(self, observation, rng):
        if observation.groceries < observation.grocery_need_daily:
            return [Action("buy", amount=1, delay_hours=0.3)]
        return [Action("none")]

w = World(Config(households=10000, days=7, trace="my-trace.ndjson"), policy=ExamplePolicy())
print(w.run())
```

Policy code receives only frozen participant observations (with personal balances/inventory, on-site observations, access-gated requested data, received messages and pending request IDs) and an RNG. The engine owns all account balances, inventory, transport reservations, message routing and the event queue. Policies may emit **lists of ordinary actions**, including `buy`, `buy_medicine`, `commute`, `pay_bill`, `clinic`, `query`, `send`, `forward`, `ask`, `agree`, `disagree`, `intended_message`, `completed_message`, `schedule`, `cancel`, or `none`. The world validates claims, eligibility, capacity, ownership, information access and transaction feasibility. Future comparison-policy objectives do not exist in the model.

See `docs/technical.md` for all action semantics, conservation equations and domain couplings; `provenance.json` for 66 parameter/source records; `docs/limitations.md` for failures and gaps; `reports/validation.md` for actual measurements. Run `python scripts/validate.py` to generate paired-seed comparison outputs and domain shock smoke checks.

## Status

All automated unit/integration tests must pass before using the generated output as a software example. This build is **not the validated frozen release specified in the assignment**. Independent empirical disturbance benchmarks, local calibration, legal banking implementation, electrical topology / protective relays, GIS road network, service continuity protocols, and million-unit run profiling are still outstanding. `MANIFEST.sha256` identifies the artifact contents, not scientific validation.

License: MIT (`LICENSE`).

## Partial source-linked calibration (0.2.0-dev supplement)

The previous 0.1.0 internal-software report and traces remain reproducible legacy baseline artifacts. The new opt-in benchmark/calibration workflow is **partial and explicitly not independently validated**:

```bash
python scripts/calibrate.py
regional-sim --config configs/calibrated_2024.json --shock-json configs/aep_2022_proxy_shocks.json --out output/calibrated_case
regional-sim --config configs/calibrated_2024.json --out output/calibrated_control
```

It fits a configurable BPR free-flow time to a 2024 Columbus ACS commute-time **proxy** and two *external* supply multipliers to approximate June 2022 AEP outage-count **proxies**, not to a physical circuit reconstruction. Source observations and explicit comparability limits are in `benchmarks/observations.json`; trials, seed checks and measured paired outcomes are in `calibration/results.json`; interpretations and missing independent validation are in `docs/calibration.md`. Three new regression tests cover precise shock-tick ordering, outage boundedness and free-flow sensitivity. The provenance generator now produces **56** entries, including observed benchmarks and separately flagged inverse-fitted C-level quantities. The archived 0.1.0 report's statement of 16 tests / 49 parameters describes the older snapshot, not this supplement.

The new `--free-flow-minutes` flag (`Config.free_flow_minutes`) defaults to the legacy 24 minutes; the calibrated configuration sets about 23.7693. The `power_unserved_households_*` counters describe a fixed-rank *scalar service proxy*, **not an engineered feeder/customer outage circuit model**. Externally scheduled restoration remains an input. Never use the two fitted points as evidence of independent shock-response validation.

## Optional reversible operational availability (0.3.0-dev)

Operational absence/closure is not mortality, serious illness, structural damage or automatic bankruptcy. A provisional evidence-linked **stated-response** fit represents households' temporary relocation under actual local grid loss, and store-site normal grid availability separately from synthetic retailer operating workarounds. Temporary relocation consumes road capacity; absent households cannot perform local work, shopping or clinic visits, but are retained in the population and outside-region food/medicine requirements are logged as **unresolved boundary needs**, not assumed fulfilled. The extension is on by default; `--no-availability` disables it.

```bash
python -m scripts.validate_availability
regional-sim --config configs/development.json --no-availability --out output/ablation
```

See [docs/operational_availability.md](docs/operational_availability.md), `benchmarks/availability_observations.json` and `calibration/availability_results.json` for fitted survey endpoints, actual blackout and hurricane comparators *not* fitted, three-seed checks and all gaps. These are **not independently historically validated**; physical buildings have no damage or safety state. Prior example output folders and `calibration/results.json` were generated with the earlier 0.2.0-dev version; re-run them to compare model versions.
